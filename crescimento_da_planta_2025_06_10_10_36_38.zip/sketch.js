let plantHeight = 0;
let waterLevel = 0;
let soilMoisture = 50;
let rainLevel = 0;
let isWatering = false;
let plantColor;
let irrigationOn = false;
let rainOn = false;
let growthSensor = 0;

function setup() {
  createCanvas(800, 600);
  plantColor = color(34, 139, 34); // Cor inicial da planta
  textSize(16);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(135, 206, 235); // Céu azul claro
  
  drawFarm();
  drawSun();
  drawRainClouds();
  drawPlant();
  drawIrrigationSystem();
  drawGrowthSensor();
  drawControls();
  
  // Lógica de irrigação
  if (irrigationOn) {
    waterLevel += 0.1;
    if (waterLevel > 255) waterLevel = 255;
    soilMoisture = map(waterLevel, 0, 255, 50, 100);
  } else {
    waterLevel -= 0.05;
    if (waterLevel < 0) waterLevel = 0;
    soilMoisture = map(waterLevel, 0, 255, 50, 100);
  }

  // Lógica de chuva
  if (rainOn) {
    rainLevel += 0.2;
    if (rainLevel > 255) rainLevel = 255;
    soilMoisture = map(rainLevel, 0, 255, 50, 100);
  } else {
    rainLevel -= 0.1;
    if (rainLevel < 0) rainLevel = 0;
  }

  // Atualizando a cor da planta de acordo com a irrigação
  plantColor = lerpColor(color(34, 139, 34), color(0, 128, 0), soilMoisture / 100);
  growthSensor = map(plantHeight, 0, 150, 0, 100);
  
  // Crescimento da planta
  if (plantHeight < 150) {
    plantHeight += 0.1;
  }
}

function drawFarm() {
  // Solo
  fill(139, 69, 19);
  noStroke();
  rect(0, height * 0.75, width, height * 0.25);
}

function drawSun() {
  fill(255, 223, 0);
  noStroke();
  ellipse(width * 0.8, height * 0.2, 100, 100);
}

function drawRainClouds() {
  fill(255, 255, 255, rainLevel);
  noStroke();
  ellipse(200, 100, 150, 80);
  ellipse(250, 120, 100, 60);
  ellipse(300, 100, 150, 80);
}

function drawPlant() {
  fill(plantColor);
  noStroke();
  ellipse(width / 2, height * 0.75 - plantHeight, 20, 20); // Folha
  rect(width / 2 - 5, height * 0.75 - plantHeight, 10, plantHeight); // Caule
}

function drawIrrigationSystem() {
  // Irrigação - linha de irrigação
  fill(0, 0, 255, 100); // Cor da água
  noStroke();
  rect(0, height * 0.75, width, 5); // Linha representando o sistema de irrigação
}

function drawGrowthSensor() {
  fill(0);
  textSize(20);
  text("Crescimento da Planta: " + Math.round(growthSensor) + "%", width / 2, 50);
}

function drawControls() {
  // Botões de controle para irrigação e clima
  fill(0, 255, 0);
  rect(50, height - 100, 150, 50); // Botão de irrigação
  fill(0);
  textSize(18);
  text("Irrigação: " + (irrigationOn ? "ON" : "OFF"), 125, height - 75);
  
  fill(0, 0, 255);
  rect(220, height - 100, 150, 50); // Botão de chuva
  fill(0);
  text("Chuva: " + (rainOn ? "ON" : "OFF"), 295, height - 75);
}

function mousePressed() {
  // Interatividade - Irrigação
  if (mouseX > 50 && mouseX < 200 && mouseY > height - 100 && mouseY < height - 50) {
    irrigationOn = !irrigationOn;
  }
  
  // Interatividade - Chuva
  if (mouseX > 220 && mouseX < 370 && mouseY > height - 100 && mouseY < height - 50) {
    rainOn = !rainOn;
  }
}
